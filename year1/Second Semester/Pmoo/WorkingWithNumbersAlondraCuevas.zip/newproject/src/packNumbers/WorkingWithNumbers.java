package packNumbers;

public class WorkingWithNumbers {
 public boolean isEven(int n) {
	 return n % 2 == 0; // verifica si n que es cualquier numero es par o no 
 }
 public void evenValues(int n) {
	 System.out.println("Numeros pares comprendidos entre 1 y "+ n + ":");
	 boolean first = true; // para que no haya una coma al inicio 
	 
	 for (int i = 1; i <= n; i++) { // siendo que i es 1, 1 menor o igual que n, se le agrega a i + 1, aqui va pasando por cada numero para comprabar si es par o no
	  if (isEven(i)) {
		  if (!first) {
			  System.out.println(","); // que agregue coma despues del primer numero
		  }
		  System.out.print(i);
		  first = false; //despues del primer numero se comienza a separar por coma
	  }
	  }
 }
}
