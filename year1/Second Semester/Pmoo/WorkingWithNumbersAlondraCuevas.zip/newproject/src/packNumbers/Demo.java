package packNumbers;
import java.util.Scanner;
public class Demo {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		
      WorkingWithNumbers numbers = new WorkingWithNumbers(); // instancia workingWithNumbers para poder llamar a los metodos dentro de esta clase
      // ejemplo: 
      System.out.println ("¿es par 8?"+ numbers.isEven(8));
      System.out.println("numeros pares hasta 37:");
      numbers.evenValues(37);
   
      Scanner consola = new Scanner (System.in);
      // pedir un numero para probar que isEven 
      System.out.println("\r Ingresa un numero para probar que es par");
      int num = consola.nextInt();
      boolean esPar = numbers.isEven(num);
      System.out.println("¿Es"+" "+ num +" "+"par?"+ " "+esPar);
      
      // numeros pares entre 1 y el que se recibe como parametro: n
      System.out.println("Ingresa un numero mayor que 1 para que sea utilizado como parametro y encontrar los numeros pares hasta este parametro desde 1");
      int parametro = consola.nextInt();
      numbers.evenValues(parametro);
      
      consola.close();
      
	};

}
